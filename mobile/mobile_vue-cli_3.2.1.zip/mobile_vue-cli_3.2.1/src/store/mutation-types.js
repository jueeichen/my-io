export const RECEIVE_NEWSBYID = 'receive_newsbyid'



