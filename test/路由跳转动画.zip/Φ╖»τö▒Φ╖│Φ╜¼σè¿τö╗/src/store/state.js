export default {
  newsData:{}
}
